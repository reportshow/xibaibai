<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '2661929417' );
define( "WB_SKEY" , '06eab69ce972ddf69195e4a762c23ac5' );
define( "WB_CALLBACK_URL" , 'http://ding.scicompound.com/sweet/oauth/weibo/callback.php' );
